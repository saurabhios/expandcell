//
//  ExapandCellVC.swift
//  SaurabhPractical
//
//  Created by S@ur@bh on 12/9/19.
//  Copyright © 2019 S@ur@bh. All rights reserved.
//

import UIKit

class ExapandCellVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet var tblviewExpand : UITableView!

    var arrayHeader = [1, 1, 1, 1]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
              return arrayHeader.count
          }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return (self.arrayHeader[section] == 0) ? 0 : 4
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
           cell.textLabel?.text = "section: \(indexPath.section)  row: \(indexPath.row)"
           return cell
       }
       
       func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 40
       }
       
       func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 40))
                  viewHeader.backgroundColor = UIColor.darkGray // Changing the header background color to gray
                  let button = UIButton(type: .custom)
                  button.frame = viewHeader.bounds
                  button.tag = section // Assign section tag to this button
                  button.addTarget(self, action: #selector(tapSection(sender:)), for: .touchUpInside)
                  button.setTitle("Section: \(section)", for: .normal)
                  viewHeader.addSubview(button)
                  return viewHeader
       }
       @objc func tapSection(sender: UIButton) {
           self.arrayHeader[sender.tag] = (self.arrayHeader[sender.tag] == 0) ? 1 : 0
           tblviewExpand.reloadSections([sender.tag], with: .fade)
       }
      
    
   
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


