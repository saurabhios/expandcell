//
//  ViewController.swift
//  SaurabhPractical
//
//  Created by S@ur@bh on 12/9/19.
//  Copyright © 2019 S@ur@bh. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var txtName : UITextField!
    @IBOutlet var txtPass : UITextField!
    @IBOutlet var btnLogin : UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
     
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
       textField.resignFirstResponder()
       return true
    }
    
    
    @IBAction func btnClicked(_ sender: Any)
    {

        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ExapandCellVC") as? ExapandCellVC
        self.navigationController?.pushViewController(vc!, animated: true)
        
       
               let parameters: Parameters = [
                   "userid": "trupen@xceltec.in","password" : "Tcl806**","deviceid" : "d12342","role" : "2","fcmtoken" : "fcm12342"]

             
               let url = "http://mycare.xceltec.com/app/user/login"
               
               Alamofire.request(url, method:.post, parameters:parameters).responseJSON { response in
                   switch response.result {
                   case .success:
                       print(response)
                    
                       
                   case .failure(let error):
                       print(error)
                   }
                   
               }
    }
    

}

